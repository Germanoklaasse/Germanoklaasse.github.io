
public class Card {
	
	private String suit;
	private String name;
	private int value;
	
	public Card(String suit, String name, int value) {
		this.suit = suit;
		this.name = name;
		this.value = value;
	}
	
	public String toString() {
		return "["+name+"-"+suit+"]";
	}
	
	public boolean isHigherOrEqual(Card c) {
		if (this.value==1)
			return true;
		if (c.value==1)
			return false;
		if (this.value>=c.value)
			return true;
		return false;
	}
}
