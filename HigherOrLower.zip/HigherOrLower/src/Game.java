import java.util.Scanner;

public class Game {

	private static int score;
	private static Card currentCard;
	private static Card nextCard;
	private static Deck deck;
	private static Scanner sc;
	
	public static void gameTurn() {
		System.out.println("Current card : "+currentCard.toString());
		System.out.print("Higher or Lower? ");
		String answer = sc.nextLine();
		nextCard = deck.getNextCard();
		if (answer.equalsIgnoreCase("higher") && nextCard.isHigherOrEqual(currentCard)) {
			correct();
		}
		else if (answer.equalsIgnoreCase("lower") && !nextCard.isHigherOrEqual(currentCard)) {
			correct();
		}
		else gameOver();
	}
	
	public static void correct() {
		score++;
		System.out.println("Score : "+score);
		currentCard = nextCard;
		gameTurn();
	}
	
	public static void gameOver() {
		System.out.println("Next card : "+nextCard.toString());
		System.out.println("\n***** Game Over *****");
		System.out.println("Final Score : "+score);
		System.exit(0);
	}
	
	public static void main(String[] args) {
		System.out.println("***** Game Start *****\n");
		sc = new Scanner(System.in);
		deck = new Deck();
		currentCard = deck.getNextCard();
		gameTurn();
	}
}
