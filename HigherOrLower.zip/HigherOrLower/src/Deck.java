import java.util.ArrayList;
import java.util.Random;

public class Deck {
	
	private ArrayList<Card> cards = new ArrayList<Card>();
	
	public Deck() {
		String suit;
		for (int suitIndex=1; suitIndex<5; suitIndex++ ) {
			if (suitIndex==1) suit = "Clubs";
			else if (suitIndex==2) suit = "Diamonds";
			else if (suitIndex==3) suit = "Hearts";
			else suit = "Spades";
			for (int i=1; i<14; i++) {
				if (i==1) 
					cards.add(new Card(suit, "Ace", i));
				else if (i<11)
					cards.add(new Card(suit, String.valueOf(i), i));
				else if (i==11) 
					cards.add(new Card(suit, "Jack", i));
				else if (i==12) 
					cards.add(new Card(suit, "Queen", i));
				else if (i==13) 
					cards.add(new Card(suit, "King", i));
			}
		}
	}
	
	public Card getNextCard() {
		Random r = new Random();
		int rand = r.nextInt(cards.size());
		return cards.remove(rand);
	}

	public ArrayList<Card> getCards() {
		return cards;
	}
	
}
